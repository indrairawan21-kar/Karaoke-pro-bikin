# Karaoke Pro Android — Prototype 0.1

## Status dan batasan
Ini adalah proyek awal Android Studio yang dapat dibangun menjadi APK. Ini **belum** merupakan mesin karaoke penuh seperti di tempat karaoke:
- Tombol pencarian membuka hasil pencarian YouTube di aplikasi/browser YouTube.
- Aplikasi ini tidak mengambil atau memutar ulang stream YouTube di dalam aplikasi.
- Antrean saat ini berupa daftar judul lokal; belum otomatis memainkan lagu berikutnya.
- Dua mikrofon harus masuk melalui receiver dual-channel dan mixer eksternal. Kontrol mic/echo/reverb belum dikendalikan aplikasi.
- Lirik ditampilkan oleh video karaoke YouTube yang dipilih, bukan dibuat/disinkronkan oleh aplikasi.

Pembatasan tersebut sengaja dipilih agar pemutaran tetap melalui layanan YouTube resmi dan tidak menjanjikan fungsi audio yang belum diimplementasikan.

## Cara membangun APK
1. Instal Android Studio versi terbaru pada komputer.
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `KaraokeProAndroid`.
4. Tunggu Gradle Sync selesai.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android dan instal. Android mungkin meminta izin instalasi dari sumber tersebut.

## Kebutuhan
- Android Studio dan Android SDK Platform 35.
- Koneksi internet untuk pencarian YouTube.
- Receiver wireless dua mic + mixer + speaker aktif untuk suara karaoke.

## Catatan
Proyek ini disediakan sebagai starter project. Build dan uji pada perangkat Android nyata tetap diperlukan. Untuk kontrol mixer digital dari aplikasi, dibutuhkan model mixer/protokol yang kompatibel.
